# -*- coding: utf-8 -*-
from enigma import getDesktop, RT_HALIGN_LEFT, RT_VALIGN_TOP, gFont

from Components.Label import Label
from Components.ActionMap import ActionMap
from Components.Sources.List import List 
from Components.PluginList import resolveFilename 
from Components.Sources.Progress import Progress
from Components.Sources.StaticText import StaticText

from Screens.Standby import TryQuitMainloop
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen

from Tools.LoadPixmap import LoadPixmap
from Tools.Directories import fileExists, SCOPE_PLUGINS
from Tools.Downloader import downloadWithProgress
	
from Plugins.Plugin import PluginDescriptor

from twisted.web.client import getPage, downloadPage

from .utils import reloadChannelList, CommonChannelListScreen, Djcrash, CommonPiconListScreen, decode_html, safe_tar_extract, remove_wildcard, verify_md5
import os

version = "20221219"

class ChannelListUpdateMenu(Screen):
	skin = '''<screen name="ChannelListUpdateMenu" position="center,center" size="750,460" title="Polskie listy kanałów mod by fullkiller™" >
			<widget source="list" render="Listbox" position="10,10" size="730,240" scrollbarMode="showOnDemand" transparent="1">
				<convert type="TemplatedMultiContent">
				{"template": [
					MultiContentEntryText(pos = (115, 2), size = (620, 26), font=0, color=0x3589ff, flags = RT_HALIGN_LEFT, text = 0),
					MultiContentEntryPixmapAlphaBlend(pos = (2, 5), size = (100, 40), png = 1),
					MultiContentEntryText(pos = (115, 30), size = (620, 26), font=1, flags = RT_VALIGN_TOP | RT_HALIGN_LEFT, text = 3),
					],
					"fonts": [gFont("Regular", 24),gFont("Regular", 22)],
					"itemHeight": 60
				}
				</convert>
			</widget>
			<widget name="key_red"		position="270,230" size="280,40" font="Regular;24" halign="center" valign="center" backgroundColor="red" />
			<widget name="info" position="5,280" size="740,180" font="Regular;28" halign="center" backgroundColor="#1a193e48"/>
		  </screen>'''
		  
	def __init__(self, session):
		Screen.__init__(self, session)
		self.list = []
		self["list"] = List(self.list)
		
		self["key_red"] = Label("Aktualizacja pluginu")
		
		self.updateList()
		self.check_updates(0)
		
		self["info"] = Label("Plugin do aktualizacji list kanałow tworzonych przez HSWG, DjCrash'a, Krzyśka80 ,fullkiller™ i @Seto. Bez ich pracy nie byłoby list kanałów.\n\nRango - %s" % version)
		self["actions"] = ActionMap(["WizardActions", "ColorActions"], {"red": self.check_updates, "ok": self.KeyOk, "back": self.close})
		
	def KeyOk(self):
		self.sel = self["list"].getCurrent()
		if not self.sel:
			return
		returnValue = self.sel[2]
		if returnValue == "hswg":
				self.session.open(HSWG)
		elif returnValue == "djcrash":
				self.session.open(Djcrash)
		elif returnValue == "k80":
				self.session.open(K80)
		elif returnValue == "fk":
				self.session.open(Fk)
		elif returnValue == "master":
				self.session.open(Master)
		elif returnValue == "seto":
				self.session.open(Seto)
		elif returnValue == "masterpicon":
				self.session.open(MasterPicon)

	def updateList(self):
		self.list = []
		mypath = resolveFilename(SCOPE_PLUGINS)
		mypath = os.path.join(mypath, "Extensions/RangoPolishChannelsUpdater/images/")

		items = [
			("hswg.png", _("Pobierz listę od HSWG_(bzyk83)"), _("Listy dla HotBird 13.0E oraz Astra 19.2E"), "hswg"),
			("djcrash.png", _("Pobierz listę od DjCrasha"), _("Listy dla HotBird 13.0E, 19.2E, 23,5E, 28,2E oraz obrotnica"), "djcrash"),
			("k80.png", _("Pobierz listę od Krzysiek80"), _("Listy dla HotBird 13.0E"), "k80"),
			("fk.png", _("Pobierz listę od fullkiller™"), _("Listy dla HotBird 13.0E"), "fk"),
			("ms.png", _("Pobierz config mulistalker"), _("MAC links"), "master"),
			("seto.png", _("Pobierz listę od @Seto"), _("Listy dla HotBird 13.0E oraz Astra 19.2E"), "seto"),
			("picon.png", _("Pobierz Picony od @Seto i RJ"), _("Picony dla HotBird 13.0E oraz Astra 19.2E"), "masterpicon"),
		]

		for img, name, desc, idx in items:
			mypixmap = os.path.join(mypath, img)
			png = LoadPixmap(mypixmap)
			res = (name, png, idx, desc)
			self.list.append(res)

		self["list"].list = self.list
		
	def quit(self):
		self.close()

	def errorUpdate(self, html):
		message = _('Błąd sprawdzania nowej wersji Rango Polskie Listy Kanałów. Serwer nie odpowiada.')
		self.session.open(MessageBox, message, MessageBox.TYPE_INFO, 3)

	def check_updates(self, tryb = 1):
