# -*- coding: utf-8 -*-
from Components.Language import language
try:
	from Tools.Directories import resolveFilename, SCOPE_PLUGINS, SCOPE_LANGUAGE
except:
	from Components.PluginList import resolveFilename
	from Tools.Directories import SCOPE_PLUGINS, SCOPE_LANGUAGE
from os import environ as os_environ
import gettext

def localeInit():
	lang = language.getLanguage()[:2]
	os_environ["LANGUAGE"] = lang
	gettext.bindtextdomain("RangoPolishChannelsUpdater", resolveFilename(SCOPE_PLUGINS, "Extensions/RangoPolishChannelsUpdater/locale"))

def _(txt):
	t = gettext.dgettext("RangoPolishChannelsUpdater", txt)
	if t == txt:
		t = gettext.gettext(txt)
	return t

localeInit()
language.addCallback(localeInit)
