# -*- coding: utf-8 -*-
from . import _
import gettext
from Tools.Directories import resolveFilename, SCOPE_PLUGINS

def localeInit():
	gettext.bindtextdomain("RangoPolishChannelsUpdater", resolveFilename(SCOPE_PLUGINS, "Extensions/RangoPolishChannelsUpdater/locale"))

def _(txt):
	t = gettext.dgettext("RangoPolishChannelsUpdater", txt)
	if t == txt:
		t = gettext.gettext(txt)
	return t

localeInit()
